/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistema.proyecto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

public class UserDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/sistema_de_informes"; // Cambia los espacios a guiones bajos
    private static final String USER = "Samuel"; // Cambia esto si tu usuario es diferente
    private static final String PASSWORD = "2006"; // Cambia esto si tienes contraseña

    // Conectar a la base de datos
    private Connection connect() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    // Crear un nuevo usuario
    public void createUser(String ID_Cedula, String Nombre, String Celular, String Correo) {
        String sql = "INSERT INTO users (ID_Cedula, name, Celular, correo) VALUES (?, ?, ?, ?)"; // Cambiado email por correo
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, ID_Cedula);
            pstmt.setString(2, Nombre);
            pstmt.setString(3, Celular);
            pstmt.setString(4, Correo);
            pstmt.executeUpdate();
            System.out.println("Usuario añadido con éxito");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Leer todos los usuarios
    public void readUsers() {
        String sql = "SELECT * FROM users";
        try (Connection conn = connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("ID_Cedula: " + rs.getString("ID_Cedula") + 
                                   ", Nombre: " + rs.getString("name") + 
                                   ", Celular: " + rs.getString("Celular") + 
                                   ", Correo: " + rs.getString("correo")); // Cambiado email por correo
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Actualizar un usuario
    public void updateUser(int id, String name, String Correo, String Celular) { // Cambiado email por Correo
        String sql = "UPDATE users SET name = ?, correo = ?, Celular = ? WHERE id = ?"; // Cambiado email por correo
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, Correo); // Cambiado email por Correo
            pstmt.setString(3, Celular);
            pstmt.setInt(4, id);
            pstmt.executeUpdate();
            System.out.println("Usuario actualizado con éxito");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Eliminar un usuario
    public void deleteUser(int id) {
        String sql = "DELETE FROM users WHERE id = ?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            System.out.println("Usuario eliminado con éxito");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método principal para probar el CRUD
    public static void main(String[] args) {
        UserDAO dao = new UserDAO();

        // Crear nuevos usuarios es un ejemplo que me proporcionaron cuando estaba investigandom, pero se puede ejecutar para agregar un nuevo usuario.
        dao.createUser("12345678", "Juan Pérez", "987654321", "juan@example.com");
        dao.createUser("87654321", "Ana Gómez", "123456789", "ana@example.com");

        // Leer usuarios
        System.out.println("Usuarios actuales:");
        dao.readUsers();

        // Actualizar usuario
        dao.updateUser(1, "Juan Pérez Actualizado", "juan.actualizado@example.com", "111111111");

        // Leer usuarios de nuevo
        System.out.println("Usuarios después de la actualización:");
        dao.readUsers();

        // Eliminar un usuario
        dao.deleteUser(2);

        // Leer usuarios nuevamente
        System.out.println("Usuarios después de la eliminación:");
        dao.readUsers();
    }
}




