package com.sistemas_de_informes.pruebas.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController


 public class HellowordRestController {
    @GetMapping("/hello")
    public String Helloword(){
        return "Hello, word" +
                "<!DOCTYPE html>\n" +
                "<html lang=\"es\">\n" +
                "    \n" +
                "    <head> <!--codificacion, titulo, adaptacion de pantalla-->\n" +
                "        <meta charset=\"utf-8\">\n" +
                "        <meta name=\"viewport\" content=\"width=device-width\">\n" +
                "        <link rel=\"stylesheet\" href=\"1inicio sistema.css\">\n" +
                "        <title>Sistema de creacion de informes </title>\n" +
                "        <meta name=\"theme-color\" content=\"#89f\">\n" +
                "        \n" +
                "        \n" +
                "    </head>\n" +
                "\n" +
                " \n" +
                "    <body>\n" +
                "\n" +
                "        <section>\n" +
                "            <div class=\"encabezado\">  <!--Encabezado de pagina-->\n" +
                "                <header>\n" +
                "                    <p>Bienvenido al sistema, aqui podras generar tus informes</p>\n" +
                "                </header>\n" +
                "            </div>\n" +
                "        </section>\n" +
                "\n" +
                "   \n" +
                "        <main>  <!--seccion de inicio-->\n" +
                "            \n" +
                "            \n" +
                "            <div class=\"contenido\"> <!-- Esta seccion sale el formulario de ingreso y/o creacion de usuario -->\n" +
                "\n" +
                "                <div id=\"Bienvenida\"> <!--Mensaje inicial-->\n" +
                "                    <h1>BIENVENIDO</h1>\n" +
                "                    <p> Hola estimado usuario, aqui podras iniciar sesion.</p>\n" +
                "                </div>\n" +
                "\n" +
                "           \n" +
                "\n" +
                "                <!--Menu de ingreso-->\n" +
                "        \n" +
                "                <div id=\"Menu\"> <!--apartado principal del formulario-->\n" +
                "                    <div id=\"img1\">\n" +
                "                    \n" +
                "                        <img id=\"imagen1\" src=\"Imagenes/gesto-saludo-personas-hombre-mujer-ropa-casual-saluda_501746-78.avif\" width=\"390\" height=\"335\" alt=\"Imagen de bienvenida\" alt=\"Imagen de bienvenida\">\n" +
                "                        \n" +
                "                    </div>\n" +
                "\n" +
                "                    <div class=\"ingreso\"> <!--Formulario de ingreso-->\n" +
                "                        <form>\n" +
                "\n" +
                "                            <h1>INGRESE SUS DATOS</h1>\n" +
                "                                \n" +
                "                             <input id=\"button1\" type=\"text\" name=\"Nombre\" placeholder=\"Ingrese su Nombre\">\n" +
                "                     \n" +
                "\n" +
                "        \n" +
                "                            <br>\n" +
                "                            <br>\n" +
                "                                \n" +
                "                                \n" +
                "                              <input id=\"button 2\" type=\"number\"min=\"0\" max=\"100\"  name=\"Cedula\" id=\"Cedula\" placeholder=\"Ingrese su Cedula\">\n" +
                "                                \n" +
                "                                \n" +
                "                            <br>\n" +
                "                            <br>\n" +
                "\n" +
                "                             <input type=\"password\" name=\"contraseña\" id=\"password\" placeholder=\"Ingrese su contraseña\">\n" +
                "                            \n" +
                "                            <br>\n" +
                "                            <br>\n" +
                "                            \n" +
                " \n" +
                "                     </form>   \n" +
                "                     \n" +
                "                     <section>\n" +
                "                           <div class=\"buttons\">\n" +
                "\n" +
                "                                <button class=\"but1\">\n" +
                "                                    <a id=\"ingresar\" href=\"2Interfaz de inicio.html\">INGRESAR</a>\n" +
                "\n" +
                "                                </button>\n" +
                "                            </div> \n" +
                "\n" +
                "                     </section>\n" +
                "                     <br>\n" +
                "\n" +
                "                 </div>\n" +
                "\n" +
                "\n" +
                "                </div>\n" +
                "                <br>\n" +
                "                <div class=\"crear perfil\">\n" +
                "\n" +
                "                    <button class=\"but2\">\n" +
                "                        <a id=\"crear\" href=\"crearusuario.html\">CREAR PERFIL</a>\n" +
                "                    </button>\n" +
                "                \n" +
                "                </div>\n" +
                "                \n" +
                "\n" +
                "            </div>\n" +
                "\n" +
                "        </main> <!--FIN DE LA CAJA CONTENIDO-->\n" +
                "\n" +
                "        <br>\n" +
                "\n" +
                "        <section>\n" +
                "\n" +
                "            <div id=\"footer\">\n" +
                "                \n" +
                "                <footer>\n" +
                "                    <h5>Hola amigazo amiguito amigo compa maquina crack socio pana mastodonte</h5>\n" +
                "                </footer>\n" +
                "\n" +
                "            </div>\n" +
                "\n" +
                "        </section>\n" +
                "\n" +
                "            \n" +
                "      \n" +
                "\n" +
                "    </body>\n";
    };
}
