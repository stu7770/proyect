const express = require("express");
const axios = require("axios"); 
const app = express();
const port = 4000; 

app.use(express.json());

// Lista de productos de aseo
const productos = [
    { id: 1001, nombre: "Multiesponja x1", precio: 3 },
    { id: 1002, nombre: "Multiesponja x2", precio: 11.25 },
    { id: 1003, nombre: "Maxisponja", precio: 11.25 },
    { id: 1004, nombre: "Mallaclorox", precio: 800 },
    { id: 1005, nombre: "despicar esponjas", precio: 2.5},
    { id: 1006, nombre: "Cocer primera", precio: 3.5},
    { id: 1007, nombre: "Cocer segunda", precio: 6.5}
];


// Array para almacenar los informes
const informes = [];

// Endpoint para obtener la lista de productos
app.get("/api/productos", (req, res) => {
    res.json(productos);
});

// Endpoint para crear un nuevo informe
app.post("/api/informes", (req, res) => {
    const { productosSeleccionados } = req.body;

    if (!productosSeleccionados || !Array.isArray(productosSeleccionados) || productosSeleccionados.length === 0) {
        return res.status(400).json({ error: "Debe seleccionar al menos un producto" });
    }

    const detalleInforme = productosSeleccionados.map(item => {
        const producto = productos.find(p => p.id === item.id);
        if (producto) {
            return {
                id: producto.id,
                nombre: producto.nombre,
                cantidad: item.cantidad,
                precioUnitario: producto.precio,
                total: item.cantidad * producto.precio
            };
        }
    }).filter(item => item !== undefined);

    const totalInforme = detalleInforme.reduce((acc, item) => acc + item.total, 0);

    const nuevoInforme = {
        id: informes.length + 1,
        fecha: new Date(),
        productos: detalleInforme,
        total: totalInforme
    };

    informes.push(nuevoInforme);

    res.status(201).json(nuevoInforme);
});

// Endpoint para obtener productos de otra API
app.get("/api/external-productos", async (req, res) => {
    try {
        const response = await axios.get("http://localhost:3000/api/productos");
        
        // Envía la respuesta de la API externa
        res.json(response.data);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error al conectar con la API externa" });
    }
});

// Endpoint para obtener todos los informes recolectados
app.get("/api/informes", (req, res) => {
    res.json(informes);
});

// Inicia el servidor en el puerto especificado
app.listen(port, () => {
    console.log(`API ejecutándose en http://localhost:${port}`);
});
