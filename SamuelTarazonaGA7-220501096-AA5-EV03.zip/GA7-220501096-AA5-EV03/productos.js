const express = require("express");
const app = express();
const port = 3000;

// Lista de productos de aseo
const productos = [
    { id: 1001, nombre: "Multiesponja x1", precio: 3 },
    { id: 1002, nombre: "Multiesponja x2", precio: 11.25 },
    { id: 1003, nombre: "Maxisponja", precio: 11.25 },
    { id: 1004, nombre: "Mallaclorox", precio: 800 },
    { id: 1005, nombre: "despicar esponjas", precio: 2.5},
    { id: 1006, nombre: "Cocer primera", precio: 3.5},
    { id: 1007, nombre: "Cocer segunda", precio: 6.5}
];

// Endpoint para obtener la lista de productos
app.get("/api/productos", (req, res) => {
    res.json(productos);
});

// Inicia el servidor
app.listen(port, () => {
    console.log(`API ejecutándose en http://localhost:${port}/api/productos`);
});
