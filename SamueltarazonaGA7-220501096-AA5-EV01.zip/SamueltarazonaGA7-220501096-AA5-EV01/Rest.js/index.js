const express = require('express');
const app = express();
app.use(express.json());

const usuarios = [
  { cedula: 1019422, name: 'Samuel', phone: 215515555, email: 'starazona144@gmail.com', enroll: true },
  { cedula: 101549422, name: 'Manuel', phone: 27875555, email: 'strazna14@gmail.com', enroll: false }
];

// Ruta raíz
app.get('/', (req, res) => {
  res.send('Rest.js');
});

// Obtener todos los usuarios
app.get('/api/usuarios', (req, res) => {
  res.send(usuarios);
});

// Obtener un usuario por cedula
app.get('/api/usuarios/:cedula', (req, res) => {
  const usuario = usuarios.find(u => u.cedula === parseInt(req.params.cedula));
  if (!usuario) return res.status(404).send('Usuario no encontrado');
  res.send(usuario);
});

// Crear un nuevo usuario
app.post('/api/usuarios', (req, res) => {
  const usuario = {
    cedula: Date.now(), 
    name: req.body.name,
    phone: parseInt(req.body.phone),
    email: req.body.email,
    enroll: Boolean(req.body.enroll)
  };
  usuarios.push(usuario);
  res.status(201).send(usuario);
});

// Eliminar un usuario por cedula
app.delete('/api/usuarios/:cedula', (req, res) => {
  const usuario = usuarios.find(u => u.cedula === parseInt(req.params.cedula));
  if (!usuario) return res.status(404).send('Usuario no existe');

  const index = usuarios.indexOf(usuario);
  usuarios.splice(index, 1);
  res.send(usuario);
});

// Iniciar el servidor
const PORT = 1000;
app.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
});

